package com.example.bookssherlock.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Cart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}