package com.example.bookssherlock.models;

public interface Credentials {

    String getEmail();

    String getPassword();
}
