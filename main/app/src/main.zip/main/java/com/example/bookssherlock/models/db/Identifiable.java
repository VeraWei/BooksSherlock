package com.example.bookssherlock.models.db;

public interface Identifiable {

    int getId();
}
